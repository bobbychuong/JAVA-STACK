public class BasicJavaTest{
  public static void main(String[] args){
    // something = new BasicJava
    BasicJava something = new BasicJava();
  // Call the class > Call the method > Invoke it
    // something.printArray();
    // something.oddNumbers();
    // something.sum(1,255);
    // something.itrArray();
    // something.findMax();
    // something.getAvg();
    // something.greaterY();
    // something.squareValues();
    // something.eliminateNeg();
    // something.maxminAvg();
    something.shiftArray();
  }
}
